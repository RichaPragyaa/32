
import './App.css';
import Navbar from './components/Navbar';
import Cards from './components/cards';

function App() {
  return (
    <>
    <Navbar/>
    <Cards/>
    </>
  );
}

export default App;
